# Docker Database DDB_MySQL with PHPMyAdminbranch

# This branch will create a MySQL Database with PHPMYADMIN access

### credentials

##### root:password
##### port 3307
##### phpmyadmin port 8091