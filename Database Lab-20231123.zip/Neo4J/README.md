# Docker Database Master DDB_NEO4J

### [Neo4j run in docker](https://neo4j.com/developer/docker-run-neo4j/)

### [Neo4j updated docs](https://neo4j.com/docs/operations-manual/current/docker/)

### [Neo4j Desktop](https://neo4j.com/download/)

### [Neo4j Desktop Docs](https://neo4j.com/docs/browser-manual/current/deployment-modes/neo4j-desktop/)

### [docker Neo4j Docker quickstart](https://www.youtube.com/watch?v=kyfcr5UPIqw)

### [docker-compose ref](https://github.com/k-code-yt/neo4j-docker/blob/main/docker-compose.yml)

##### Desktop connect to port 7999 username no4j/password 
