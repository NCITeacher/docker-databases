# Docker Database DDB_MySQL branch

# This branch will create a MySQL Database

## connect to MySQL Workbench

### set hostname to ipaddress of your ubuntu server

### set port to 3307

### test connection for user root: password

## to restore git to avoid databases in github use

```
git restore .

```
