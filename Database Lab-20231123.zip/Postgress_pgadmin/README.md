## Docker Postgress Database with pgadmin DDB_Postgress_pgadmin

### login to pgadmin ipaddress 5050
### credentials should be changed in the docker-compose file
### default admin@gmail.com  password password
### connect to server ipaddress 54320
###  user admin password admin

[Tutorial on pgadmin](https://www.youtube.com/watch?v=WFT5MaZN6g4)
[pgadmin ERD tool](https://www.youtube.com/watch?v=2pxVCzRFGeg)

