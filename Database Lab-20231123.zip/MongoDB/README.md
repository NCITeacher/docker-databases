# Docker Database DDB_MongoDB_Single with mongo-express

## This branch can creata a MongoDB single Database

[mongo-express docker](https://hub.docker.com/_/mongo-express)
[mongodb docker ref](https://hub.docker.com/_/mongo)

```
docker-compose up -d
docker-compose up --force-recreate -d

docker-compose down
docker-compose down -v

```